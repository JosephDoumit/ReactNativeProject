// MainPage.js

import React from 'react';
import { View, Text, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

function MainPage() {
  const navigation = useNavigation();

  const handleOpenApps = () => {
    // Code to open apps on the phone
    // This functionality would vary based on the platform and implementation
    alert('Opening apps...');
  };

  const handleLockApps = () => {
    // Code to lock apps on the phone
    // This functionality would vary based on the platform and implementation
    alert('Locking apps...');
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Main Page</Text>
      <Button title="Open Apps" onPress={handleOpenApps} />
      <Button title="Lock Apps" onPress={handleLockApps} />
    </View>
  );
}

export default MainPage;
