import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button, Text } from 'react-native-paper';
import firebase from './firebaseConfig';
import { useNavigation } from '@react-navigation/native';

function SetPasscodeScreen() {
  const navigation = useNavigation();

  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const verifyPin = async () => {
    try {
      const user = firebase.auth().currentUser;
      if (user) {
        const pinSnapshot = await firebase.database().ref(`users/${user.uid}/pin`).once('value');
        const savedPin = pinSnapshot.val();
        if (pin === savedPin) {
          navigation.navigate('MainPage'); // If PIN is correct, navigate to MainPage
        } else {
          setErrorMessage('Incorrect PIN');
        }
      }
    } catch (error) {
      console.error('Error verifying PIN:', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Passcode</Text>
      <TextInput
        label="Enter Passcode"
        value={pin}
        onChangeText={setPin}
        maxLength={4}
        keyboardType="numeric"
        style={styles.input}
        mode="outlined"
      />
      <Button mode="contained" onPress={verifyPin} style={styles.button}>
        Enter
      </Button>
      {errorMessage ? <Text style={styles.error}>{errorMessage}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    marginBottom: 10,
  },
  error: {
    color: 'red',
    marginBottom: 10,
    textAlign: 'center',
  },
  button: {
    marginTop: 20,
  },
});

export default SetPasscodeScreen;
