import React, { useState } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { TextInput, Button, Text } from 'react-native-paper';
import firebase from './firebaseConfig';

function SignUpScreen({ navigation }) {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [country, setCountry] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSignup = () => {
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    firebase.auth().createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        // Navigate to Sign In after successful sign up
        navigation.navigate('SignIn');
      })
      .catch((error) => {
        var errorMessage = error.message;
        setErrorMessage(errorMessage);
      });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Sign Up</Text>
      <Text style={styles.infoText}>
        Please confirm that all details are correct because you won't be able to check once you submit.
      </Text>
      <TextInput
        label="Full Names"
        placeholder="John Doe"
        value={fullName}
        onChangeText={text => setFullName(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      <TextInput
        label="Phone Number"
        placeholder="123-456-7890"
        value={phoneNumber}
        keyboardType="phone-pad"
        onChangeText={text => setPhoneNumber(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      <TextInput
        label="Country"
        placeholder="Your Country"
        value={country}
        onChangeText={text => setCountry(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      <TextInput
        label="Email"
        placeholder="example@email.com"
        value={email}
        keyboardType="email-address"
        onChangeText={text => setEmail(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      <TextInput
        label="Password"
        value={password}
        secureTextEntry
        onChangeText={text => setPassword(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      <TextInput
        label="Confirm Password"
        value={confirmPassword}
        secureTextEntry
        onChangeText={text => setConfirmPassword(text)}
        mode="outlined"
        style={styles.input}
        theme={{ colors: { primary: '#008080' } }}
      />
      {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}
      <Button mode="contained" onPress={handleSignup} style={styles.button} color="#008080">
        Sign Up
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#008080',
  },
  infoText: {
    fontSize: 16,
    marginBottom: 20,
    color: '#333',
  },
  input: {
    width: '100%',
    marginBottom: 10,
  },
  errorText: {
    color: 'red',
    marginTop: 10,
    fontSize: 14,
  },
  button: {
    marginTop: 20,
    height: 50,
  },
});

export default SignUpScreen;
